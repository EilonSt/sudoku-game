/*building a model for Gurobi optimization using the ILP method*/

#ifndef GUROBI_ILP_H_
#define GUROBI_ILP_H_

char gurobiILP(char isValidate);

#endif /* GUROBI_ILP_H_ */
