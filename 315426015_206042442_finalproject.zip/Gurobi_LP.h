/*building a model for Gurobi optimization using the LP method*/


#ifndef GUROBILP_H_
#define GUROBILP_H_
int gurobiLP(int x,int y,float threshold,char command);

#endif /* GUROBILP_H_ */
